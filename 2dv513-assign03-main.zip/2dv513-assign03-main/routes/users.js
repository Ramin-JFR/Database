'use strict'

const express = require('express')
const router = express.Router()
const controller = require('../controllers/userController')

/**
 * Login Router and logout router
 *
 */
router.get('/login', controller.login)
router.post('/loggedIn', controller.loggedIn)

router.get('/logout', controller.logout)

module.exports = router
