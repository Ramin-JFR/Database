/**
 * Register Router
 *
 */

'use strict'

const express = require('express')
const router = express.Router()

const controller = require('../controllers/artist')

router.get('/', controller.listOfArtists)

router.get('/:artist/artistFanList/',controller.fansList)

router.get('/addNewArtist/', controller.addNewArtist)
router.post('/createArtistConfirmed', controller.createArtistConfirmed)

module.exports = router
