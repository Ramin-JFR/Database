'use strict'

const express = require('express')
const router = express.Router()
module.exports = router

const controller = require('../controllers/homeController')

/**
 * home router
 *
 */
router.get('/', controller.homePage)
