/**
 * customers Router
 *
 */

'use strict'

const express = require('express')
const router = express.Router()

const controller = require('../controllers/customers')

router.get('/', controller.listOfCustomers)

router.get('/addNewCustomer/', controller.addNewCustomer)
router.post('/createCustomerConfirmed', controller.createCustomerConfirmed)

module.exports = router