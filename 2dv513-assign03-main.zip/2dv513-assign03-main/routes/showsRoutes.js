'use strict'

/**
 * Register Router
 *
 */


const express = require('express')
const router = express.Router()

const controller = require('../controllers/shows')

router.get('/', controller.listOFShows)
router.get('/:artist/show/',controller.artistShows)

router.get('/:show_id/booking/',controller.showsBooking)
router.post('/:show_id/bookingConfirmed', controller.bookingConfirmed)

router.get('/addNewShow/', controller.addNewShow)
router.post('/createConfirmed', controller.createConfirmed)

router.get('/:show_id/guestList/',controller.guestList)

router.get('/search/', controller.searchForShow)
router.post('/applySearch', controller.applySearch)

module.exports = router
