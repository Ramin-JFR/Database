# Assignment 3 - Final Project

The README file contian the instruction on how to run the web application.

## npm and MySQL setup

1. Clone the repository on your local machine.
2. Install node.js
3. Install MySQL
4. Install MySQL workbench
5. Import the backup.sql with one of these:
- With command line
```
mysql -u[username] -p[password]
``` 

```
CREATE DATABASE Show_Booking;
```
go to the 2DV513-Assign03 diredctory
```
mysql -u root -p Show_Booking < backup.sql
```
- Or you can import it with MySQL workbench. server> data Import and import the schema.

6.In the 2DV513-Assign03 (diredctory) > configs > mySQL.js you can modified the sql connection. You can change the username and password to match with your MySQL setup.

7. go to the 2DV513-Assign03 directory and run the folowing command.

```
npm install
```
8. After Install, go to the go to the 2DV513-Assign03 diredctory and run the the command to start the app
```
npm run start
```

The application will run on the localhost:8080

In the configs diredctory you can modified the sql connection. You can change the username and password to match with your MySQL setup.
