'use strict'

/**
 * App's entry point
 *
 * @author Ramin Jafari
 * @version 1.0.0
 */

const express = require('express')
const hbs = require('express-hbs')
const session = require('express-session')
const path = require('path')
const logger = require('morgan')

// // routes
const homeRouter = require('./routes/homeRouter')
const artistsRouter = require('./routes/artists')
const showsRouter = require('./routes/showsRoutes')
const customersRouter = require('./routes/customers')
const userRouter = require('./routes/users')


// App
const app = express()


app.engine('hbs',
    hbs.express4({
        defaultLayout: path.join(__dirname, 'views', 'layout', 'default'),
        partialsDir: path.join(__dirname, 'views', 'partials')
    })
)

// all environment
app.set('port', 8080)
// view engine setup
app.set('views', path.join(__dirname, 'views'))
app.set('view engine', 'hbs')

// logger
app.use(logger('dev'))
// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, 'public')))

// Populates req.session
app.use(session({
        name: 'Ramin&Rohaan',
        secret: 'Assign3',
        resave: false, // don't save session if unmodified
        saveUninitialized: false, // do not create session until something stored
        cookie: {
            httpOnly: true,
            secure: false,
            maxAge: 1000 * 60 * 60 * 24 // 1Day
        }
    })
)

app.use((req, res, next) => {
    if (req.session.flash) {
        res.locals.flash = req.session.flash
        // delete it immediately
        delete req.session.flash
    }
    next()
})

app.use((req, res, next) => {
    app.locals.userX = req.session.userName
    next()
})


// Route
app.use('/', homeRouter)
app.use('/artists', artistsRouter)
app.use('/showsView', showsRouter)
app.use('/customers', customersRouter)
app.use('/user', userRouter)


const server = app.listen(app.get('port'), () => console.log('Running on http://localhost:' + app.get('port')))

// unhandledRejections
process.on('unhandledRejection', (reason, promise) => {
    console.log('Unhandled Rejection at:', promise, 'reason:', reason.message)
    server.close(() => process.exit(1))
})


