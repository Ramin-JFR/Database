'use strict'

const con = require('../configs/mySQL');
var validator = require("email-validator");


const customersController = {}
module.exports = customersController


customersController.listOfCustomers = async (req, res, next) => {
    // Return the list of all the customer
    await con.query('SELECT * FROM Show_Booking.customers;', (err, result) => {
        res.render('manager/customersList', {viewData: result});

    })
}

customersController.addNewCustomer = async (req, res, next) => {
    res.render('manager/addCustomer')

}

customersController.createCustomerConfirmed = async (req, res, next) => {

    if (!validator.validate(`${req.body.email}`)){
        req.session.flash = {
            type: 'warning',
            msg: 'Your email address is not valid!'
        }
        res.redirect(req.get('referer'));
    } else if (req.body.firstName.trim().length && req.body.lastName.trim().length && req.body.email.trim().length ) {
    // Register a new customer
        await con.query(`INSERT INTO Show_Booking.customers (first_name, last_name, email)
            VALUES ('${req.body.firstName}', '${req.body.lastName}','${req.body.email}');`
            , (err, result) => {
                if (err?.errno === 1062) {

                    req.session.flash = {
                        type: 'warning',
                        msg: 'This email is already registered!'
                    }
                    res.redirect(req.get('referer'));


                }else{
                    req.session.flash = {
                        type: 'success',
                        msg: 'Your data registered successfully in the system!'
                    }
                    res.redirect('../../')
                }

            })
    }


}



