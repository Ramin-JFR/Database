'use strict'

const con = require('../configs/mySQL');

const artistsController = {}
module.exports = artistsController

/**
 * retrieve list of artists with their data from mysql and render the corresponding page
 * @param req
 * @param res
 * @param next
 * @returns {Promise<void>}
 */
artistsController.listOfArtists = async (req, res, next) => {
    // Return the list of artist and all time booked in artist shows (previous and future shows)
    await con.query('SELECT Count(customer_email) AS fans, artists.artist\n' +
        '        FROM booking\n' +
        '\t\tright JOIN shows ON shows.show_id = booking.show_id\n' +
        '        right JOIN artists ON shows.artist_id = artists.artist_id \n' +
        '        Group by artists.artist\n' +
        '        order by artists.artist;', (err, result) => {
        res.render('manager/artist', {viewData: result});

    })
}

/**
 * retrieve list for an artist from mysql and render the corresponding page
 * @param req
 * @param res
 * @param next
 * @returns {Promise<void>}
 */
artistsController.fansList = async (req, res, next) => {
    // Return the details of people who booked in artist shows (previous and future shows)
    await con.query('SELECT *\n' +
        'FROM customers\n' +
        'JOIN booking ON customers.email = booking.customer_email\n' +
        'JOIN shows ON shows.show_id = booking.show_id\n' +
        'JOIN artists ON artists.artist_id = shows.artist_id\n' +
        'where artists.artist= "' + req.params.artist + '";', (err, result)=>{
        res.render('manager/fanPage', {viewData: result});

    })
}


artistsController.addNewArtist = async (re, res, next) => {
    res.render('manager/addArtist')
}

/**
 * Inserting artist data to mysql
 * @param req
 * @param res
 * @param next
 * @returns {Promise<void>}
 */
artistsController.createArtistConfirmed = async (req, res, next) => {

    if (req.body.artistName2.trim().length) {
        // Insert a new artist
        con.query(`INSERT INTO Show_Booking.artists (artist) VALUES ('${req.body.artistName2}');`, (err, result) => {
            res.redirect('/artists/')
        })
    }

}
