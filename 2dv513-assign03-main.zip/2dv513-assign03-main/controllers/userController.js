'use strict'

const userController = {}
module.exports = userController


/**
 * Render login.
 *
 * @param {*} req Request.
 * @param {*} res Response.
 */
userController.login = (req, res) => {
    res.render('manager/login')
}

/**
 * Authenticates.
 *
 * @param {*} req Request.
 * @param {*} res Response.
 */
userController.loggedIn = async (req, res) => {
    try {
        if ( req.body.username.toLowerCase() === "ramin" && req.body.password.toLowerCase() === "jafari"){
            req.session.regenerate(() => {
                req.session.userName = "Ramin"
                req.session.flash = {
                    type: 'success',
                    msg: 'You logged in as a manager.'
                }
                res.redirect('../../')
            })
        }
    } catch (err) {
        req.session.flash = {
            type: 'danger',
            msg: err.message
        }
        res.redirect('../')
    }
}

/**
 * Logout.
 *
 * @param {*} req Request.
 * @param {*} res Response.
 */
userController.logout = (req, res) => {
    try {
        req.session.destroy()
        res.redirect('../..')
    } catch (err) {
        req.session.flash = {
            type: 'danger',
            msg: 'please try again, you are not log out yet!'
        }
        res.redirect('..')
    }
}
