'use strict'

const homePageController = {}
module.exports = homePageController

/**
 * homePage rendering
 *
 * @param {*} req Request
 * @Param {*} res Respond
 */
homePageController.homePage = (req, res) => {
  res.render('home/homePage')
}
