'use strict'
const moment = require('moment')


const con = require('../configs/mySQL');
const validator = require("email-validator");

const showsController = {}
module.exports = showsController


showsController.listOFShows = async (req, res, next) => {
    // Retrieve list of shows and number of guest for the show
    await con.query(`
                    Select * 
                    From (SELECT count(customer_email) AS booked, shows.show_id, artists.artist, DATE_FORMAT(shows.date, "%W %M %e %Y") AS date
                    FROM booking
                    Right JOIN shows ON shows.show_id = booking.show_id
                    JOIN artists ON shows.artist_id = artists.artist_id 
                    group by shows.date
                    ORDER BY shows.date) l
                    where l.booked <100;`
        , function (err, result) {
        res.render('manager/showsView', {viewData: result});
    })

}

showsController.guestList = async (req, res, next) => {
    // List of the guests for a chosen show
    await con.query('SELECT *, DATE_FORMAT(shows.date, "%W %M %e %Y") AS date\n' +
        'FROM customers\n' +
        'JOIN booking ON customers.email = booking.customer_email\n' +
        'JOIN shows ON shows.show_id = booking.show_id\n' +
        'JOIN artists ON artists.artist_id = shows.artist_id\n' +
        'where shows.show_id = ' + req.params.show_id + ';', function (err, result) {

            res.render('manager/guestList', {viewData: result})
        }
    )
}


showsController.artistShows = async (req, res, next) => {
    // List of shows for a specific artist
    con.query(`Select * 
                From (SELECT count(customer_email) AS booked, shows.show_id, artists.artist, DATE_FORMAT(shows.date, "%W %M %e %Y") AS date
                FROM booking
                Right JOIN shows ON shows.show_id = booking.show_id
                JOIN artists ON shows.artist_id = artists.artist_id and artists.artist = '${req.params.artist}'
                group by shows.date
                ORDER BY shows.date) l
                where l.booked < 100;`,
        (err, result) => {
        res.render('manager/artistShows', {viewData: result});
    })
}

showsController.addNewShow = async (req, res, next) => {
    res.render('manager/addShow')
}

showsController.createConfirmed = async (req, res, next) => {
    let dateIsValid = moment(req.body.year + '-' + req.body.month + '-' + req.body.day).isValid()
    if (dateIsValid && req.body.artistName.trim().length && req.body.year.trim().length && req.body.month.trim().length && req.body.day.trim().length) {
        let date = req.body.year + '-' + req.body.month + '-' + req.body.day
        if (dateIsValid) {

            // Insert a new show with details on the shows table
            await con.query(`INSERT INTO Show_Booking.shows (artist_id, date) 
                        VALUES ((SELECT artist_id  FROM Show_Booking.artists WHERE artist = '${req.body.artistName}'), '${date}');`
                , function (err, result) {


                    if (err?.errno == 1062) {
                        req.session.flash = {
                            type: 'warning',
                            msg: 'There is a show in that day, please choose another day.'
                        }
                        res.redirect(req.get('referer'));

                    } else if (err?.errno == 1048) {

                        req.session.flash = {
                            type: 'warning',
                            msg: 'You should add the artist first.'
                        }
                        res.redirect('../../artists/addNewArtist/')
                    }
                    if (result?.affectedRows === 1) {
                        req.session.flash = {
                            type: 'success',
                            msg: 'New show added '
                        }
                        res.redirect('../showsView/')
                    }
                })
        }

    } else if (!dateIsValid) {
        req.session.flash = {
            type: 'warning',
            msg: 'Date is not valid. '
        }
        res.redirect(req.get('referer'));
    } else {
        req.session.flash = {
            type: 'warning',
            msg: 'Form should be fill completely '
        }
        res.redirect(req.get('referer'));
    }
}


showsController.showsBooking = async (req, res, next) => {
    // Retrieve data for a specific show
    con.query(`SELECT artists.artist, DATE_FORMAT(shows.date, "%W %M %e %Y") AS date,  shows.show_id
                FROM artists
                 JOIN shows
                WHERE shows.show_id = ${req.params.show_id}
                AND artists.artist_id = shows.artist_id;`, (req, result) => {

        res.render('manager/booking', {viewData: result});
    })
}


showsController.bookingConfirmed = async (req, res, next) => {

    if (!validator.validate(`${req.body.email}`)) {
        req.session.flash = {
            type: 'warning',
            msg: 'Your email address is not valid!'
        }
        res.redirect(req.get('referer'));
    } else {


        // Insert if customer data does not exist
        await con.query(`INSERT INTO Show_Booking.customers (first_name, last_name, email)
                SELECT '${req.body.firstName}', '${req.body.lastName}', '${req.body.email}'
                WHERE NOT exists (SELECT * FROM Show_Booking.customers
                    WHERE email = '${req.body.email}');`)

        // Insert new booking for a show
        await con.query(`INSERT INTO Show_Booking.booking (customer_email, show_id) 
                     Select  '${req.body.email}', ${req.params.show_id} WHERE NOT EXISTS (SELECT * FROM Show_Booking.booking 
                                WHERE customer_email = '${req.body.email}'
                                AND show_id = ${req.params.show_id});`
            , (err, result) => {

                if (result.affectedRows === 0) {
                    req.session.flash = {
                        type: 'warning',
                        msg: 'This is email is already used for this show. please insert  another email for new registration. '
                    }
                    res.redirect(req.get('referer'));
                } else if (result.affectedRows === 1) {
                    req.session.flash = {
                        type: 'success',
                        msg: 'You successfully registered for this show. welcome to the show at 9 pm.'
                    }
                    res.redirect(req.get('referer'));
                }

            }
        )
    }

}


showsController.searchForShow = async (req, res, next) => {
    res.render('manager/searchFor')
}

showsController.applySearch = async (req, res, next) => {
    let dateIsValid1 = moment(req.body.year1 + '-' + req.body.month1 + '-' + req.body.day1).isValid()
    let dateIsValid2 = moment(req.body.year2 + '-' + req.body.month2 + '-' + req.body.day2).isValid()
    let date1 = req.body.year1 + '-' + req.body.month1 + '-' + req.body.day1
    let date2 = req.body.year2 + '-' + req.body.month2 + '-' + req.body.day2

    if (dateIsValid1 && dateIsValid2) {
        // search for shows in a period
        con.query('SELECT count(customer_email) AS booked, shows.show_id, artists.artist, DATE_FORMAT(shows.date, "%W %M %e %Y") AS date\n' +
            'FROM booking\n' +
            'Right JOIN shows ON shows.show_id = booking.show_id\n' +
            'JOIN artists ON shows.artist_id = artists.artist_id \n' +
            'WHERE shows.date >= \'' + date1 + '\' AND shows.date <= \'' + date2 + '\'\n' +
            'group by shows.date\n' +
            'ORDER BY shows.date;', (err, result) => {

            res.render('manager/showsView', {viewData: result});
        })
    }else{
        req.session.flash = {
            type: 'warning',
            msg: 'dates are not valid. '
        }
        res.redirect(req.get('referer'));
    }


}