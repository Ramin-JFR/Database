const mysql = require('mysql');

let con = mysql.createConnection({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: '1234567890',
    database: 'Show_Booking'
})

con.connect((err)=>{
    if(err) throw err;
    else
        console.log('mySQL Is Connected');
});

module.exports = con;






